package com.test.generation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenerationApplication {

    public static void main(String[] args) {
        SpringApplication.run(GenerationApplication.class, args);
    }

}
