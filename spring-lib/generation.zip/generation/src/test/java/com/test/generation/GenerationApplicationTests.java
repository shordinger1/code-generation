package com.test.generation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenerationApplicationTests {

    @Test
    void contextLoads() {
    }

}
